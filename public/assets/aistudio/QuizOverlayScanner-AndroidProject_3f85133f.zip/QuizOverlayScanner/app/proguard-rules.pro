# Giữ các data class phục vụ serialize/deserialize JSON của Gemini REST API
-keep class com.example.quizoverlay.network.** { *; }
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-dontwarn okhttp3.**
-dontwarn okio.**
