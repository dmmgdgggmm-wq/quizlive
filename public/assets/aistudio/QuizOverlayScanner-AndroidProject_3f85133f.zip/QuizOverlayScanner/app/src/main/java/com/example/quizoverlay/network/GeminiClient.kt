package com.example.quizoverlay.network

import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.IOException
import java.util.concurrent.TimeUnit

// ======================== MODELS CHO GEMINI REST API ========================

data class GeminiRequest(
    @SerializedName("system_instruction")
    val systemInstruction: ContentInstruction? = null,
    @SerializedName("contents")
    val contents: List<ContentItem>,
    @SerializedName("generationConfig")
    val generationConfig: GenerationConfig
)

data class ContentInstruction(
    @SerializedName("parts")
    val parts: List<PartItem>
)

data class ContentItem(
    @SerializedName("role")
    val role: String = "user",
    @SerializedName("parts")
    val parts: List<PartItem>
)

data class PartItem(
    @SerializedName("text")
    val text: String? = null,
    @SerializedName("inline_data")
    val inlineData: InlineData? = null
)

data class InlineData(
    @SerializedName("mime_type")
    val mimeType: String = "image/jpeg",
    @SerializedName("data")
    val data: String
)

data class GenerationConfig(
    @SerializedName("temperature")
    val temperature: Float = 0f,
    @SerializedName("maxOutputTokens")
    val maxOutputTokens: Int = 1024,
    @SerializedName("thinkingConfig")
    val thinkingConfig: ThinkingConfig? = null
)

data class ThinkingConfig(
    @SerializedName("thinkingLevel")
    val thinkingLevel: String? = null, // Dùng cho Gemini 3 ("low" | "medium" | "high")
    @SerializedName("thinkingBudget")
    val thinkingBudget: Int? = null    // Dùng cho Gemini 2.5 (0 | 1024 | 4096)
)

data class GeminiResponse(
    @SerializedName("candidates")
    val candidates: List<Candidate>? = null
)

data class Candidate(
    @SerializedName("content")
    val content: CandidateContent? = null,
    @SerializedName("finishReason")
    val finishReason: String? = null
)

data class CandidateContent(
    @SerializedName("parts")
    val parts: List<ResponsePart>? = null
)

data class ResponsePart(
    @SerializedName("text")
    val text: String? = null,
    @SerializedName("thought")
    val thought: Boolean? = null
)

// Model phản hồi khi gọi GET v1beta/models?key=...
data class ModelListResponse(
    @SerializedName("models")
    val models: List<GeminiModelInfo>? = null
)

data class GeminiModelInfo(
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("displayName")
    val displayName: String? = null,
    @SerializedName("supportedGenerationMethods")
    val supportedGenerationMethods: List<String>? = null
)

// Chi tiết Model dùng để ping kiểm tra mà không tốn quota generateContent
data class GeminiModelDetails(
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("displayName")
    val displayName: String? = null,
    @SerializedName("inputTokenLimit")
    val inputTokenLimit: Int? = null,
    @SerializedName("outputTokenLimit")
    val outputTokenLimit: Int? = null
)

data class PingResult(
    val model: String,
    val displayName: String,
    val latencyMs: Long,
    val inputTokenLimit: Int,
    val outputTokenLimit: Int
)

private sealed class CallOutcome {
    data class Success(val text: String) : CallOutcome()
    data class HttpError(val code: Int, val message: String) : CallOutcome()
    object NetworkOrEmptyError : CallOutcome()
}

// ======================== RETROFIT SERVICE INTERFACE ========================

interface GeminiApiService {
    @GET("v1beta/models")
    suspend fun listModels(
        @Query("key") apiKey: String
    ): Response<ModelListResponse>

    @GET("v1beta/models/{model}")
    suspend fun getModel(
        @Path("model") model: String,
        @Query("key") apiKey: String
    ): Response<GeminiModelDetails>

    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): Response<GeminiResponse>
}

// ======================== GEMINI CLIENT ========================

class GeminiClient {

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    }

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val apiService: GeminiApiService = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(GeminiApiService::class.java)

    /**
     * Tự động truy vấn danh sách các mô hình AI khả dụng cho API Key vừa nhập.
     */
    suspend fun fetchAvailableModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key trống"))
        }

        try {
            val response = apiService.listModels(cleanKey)
            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    RuntimeException("Không thể tải danh sách model (HTTP ${response.code()})")
                )
            }

            val models = response.body()?.models.orEmpty()
                .filter { info ->
                    val methods = info.supportedGenerationMethods.orEmpty()
                    val rawName = info.name.orEmpty().removePrefix("models/")
                    methods.contains("generateContent") &&
                        rawName.startsWith("gemini") &&
                        !rawName.contains("embedding") &&
                        !rawName.contains("tts") &&
                        !rawName.contains("audio") &&
                        !rawName.contains("imagen") &&
                        !rawName.contains("veo")
                }
                .mapNotNull { info ->
                    info.name?.removePrefix("models/")?.takeIf { it.isNotBlank() }
                }
                .distinct()
                .sortedWith { a, b ->
                    val diff = scoreModelStrength(a) - scoreModelStrength(b)
                    if (diff != 0) diff else a.compareTo(b)
                }

            if (models.isEmpty()) {
                return@withContext Result.failure(RuntimeException("Không tìm thấy model khả dụng cho API Key này"))
            }

            Result.success(models)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Xếp hạng độ mạnh của model từ MẠNH NHẤT (số nhỏ nhất -> ở trên cùng) xuống NHẸ NHẤT / QUOTA CAO (ở dưới cùng).
     * Khi model đang chọn hết hạn mức (HTTP 429), hệ thống sẽ tự động duyệt từ trên xuống dưới theo thứ tự này.
     */
    private fun scoreModelStrength(rawId: String): Int {
        val id = rawId.lowercase().removePrefix("models/")
        return when {
            id == "gemini-3.1-pro-preview" -> 0
            id == "gemini-3-pro-preview" -> 1
            id.contains("3.1-pro") || id.contains("3-pro") -> 2
            id == "gemini-3.8-flash" -> 3
            id == "gemini-3.7-flash" -> 4
            id == "gemini-3-flash-preview" -> 5
            id.contains("3") && id.contains("flash") && !id.contains("lite") -> 6
            id == "gemini-2.5-pro" -> 7
            id == "gemini-pro-latest" -> 8
            id.contains("2.5-pro") || id.contains("pro") -> 9
            id == "gemini-2.5-flash" -> 10
            id == "gemini-flash-latest" -> 11
            id.contains("2.5-flash") && !id.contains("lite") -> 12
            id == "gemini-2.0-flash" -> 13
            id.contains("2.0-flash") && !id.contains("lite") -> 14
            id == "gemini-3.1-flash-lite-preview" -> 15
            id == "gemini-2.5-flash-lite" -> 16
            id == "gemini-flash-lite-latest" -> 17
            id.contains("lite") -> 18
            else -> 19
        }
    }

    /**
     * Xây dựng chuỗi model ưu tiên khi gọi API:
     * 1. Thử model người dùng đang chọn đầu tiên.
     * 2. Nếu model đó hết hạn mức (HTTP 429 / 503 / 404), tự động duyệt từ TRÊN XUỐNG DƯỚI
     *    theo danh sách model khả dụng đã sắp xếp từ mạnh nhất xuống nhẹ nhất.
     */
    private fun buildCandidateModelChain(
        selectedModel: String,
        availableModels: List<String>
    ): List<String> {
        val cleanSelected = selectedModel.trim().removePrefix("models/").ifBlank { "gemini-2.5-flash" }
        val sortedTopDown = (availableModels + listOf(
            "gemini-3.1-pro-preview",
            "gemini-3-flash-preview",
            "gemini-2.5-pro",
            "gemini-2.5-flash",
            "gemini-flash-latest",
            "gemini-2.5-flash-lite"
        ))
            .map { it.trim().removePrefix("models/") }
            .filter { it.isNotBlank() }
            .distinct()
            .sortedWith { a, b ->
                val diff = scoreModelStrength(a) - scoreModelStrength(b)
                if (diff != 0) diff else a.compareTo(b)
            }

        val chain = mutableListOf<String>()
        chain.add(cleanSelected)
        for (candidate in sortedTopDown) {
            if (!chain.contains(candidate)) {
                chain.add(candidate)
            }
        }
        return chain
    }

    /**
     * Tạo ThinkingConfig tương thích chính xác với từng thế hệ model:
     * - Gemini 3: dùng thinkingLevel ("low" / "medium" / "high")
     * - Gemini 2.5: dùng thinkingBudget (0 / 1024 / 4096)
     * - Các model khác (2.0, 1.5...): trả về null để tránh lỗi HTTP 400.
     */
    private fun buildCompatibleThinkingConfig(model: String, level: String): ThinkingConfig? {
        val norm = level.lowercase()
        return when {
            model.startsWith("gemini-3") -> {
                val lvl = if (norm in listOf("low", "medium", "high")) norm else "low"
                ThinkingConfig(thinkingLevel = lvl)
            }
            model.startsWith("gemini-2.5") -> {
                val budget = when (norm) {
                    "high" -> 4096
                    "medium" -> 1024
                    else -> 0
                }
                ThinkingConfig(thinkingBudget = budget)
            }
            else -> null
        }
    }

    /**
     * Thực thi 1 model đơn lẻ (tự động thử lại không kèm thinkingConfig nếu model không hỗ trợ thinking).
     */
    private suspend fun callSingleModelWithThinkingCompatibility(
        model: String,
        apiKey: String,
        userParts: List<PartItem>,
        customSystemPrompt: String?,
        thinkingLevel: String
    ): CallOutcome {
        val thinkingConfig = buildCompatibleThinkingConfig(model, thinkingLevel)
        if (thinkingConfig != null) {
            when (
                val firstOutcome = executeGenerateContentCall(
                    model = model,
                    apiKey = apiKey,
                    userParts = userParts,
                    customSystemPrompt = customSystemPrompt,
                    thinkingConfig = thinkingConfig
                )
            ) {
                is CallOutcome.Success -> return firstOutcome
                is CallOutcome.HttpError -> {
                    // Nếu hết hạn mức (429), quá tải (503), không tồn tại (404) hoặc sai key (403) -> trả về ngay để chuyển model
                    if (firstOutcome.code == 429 || firstOutcome.code == 503 || firstOutcome.code == 404 || firstOutcome.code == 403) {
                        return firstOutcome
                    }
                }
                CallOutcome.NetworkOrEmptyError -> {}
            }
        }

        return executeGenerateContentCall(
            model = model,
            apiKey = apiKey,
            userParts = userParts,
            customSystemPrompt = customSystemPrompt,
            thinkingConfig = null
        )
    }

    /**
     * Gửi ảnh chụp màn hình dạng JPEG Base64 tới model đang chọn;
     * nếu model đang chọn hết hạn mức (HTTP 429), tự động chuyển xuống model mạnh nhất khả dụng tiếp theo từ trên xuống dưới.
     */
    suspend fun analyzeQuizScreenshot(
        base64Jpeg: String,
        apiKey: String,
        modelName: String,
        thinkingLevel: String,
        customPrompt: String,
        availableModels: List<String> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext "!"
        }

        val trimmedCustomPrompt = customPrompt.trim()
        val userParts = listOf(
            PartItem(
                inlineData = InlineData(
                    mimeType = "image/jpeg",
                    data = base64Jpeg
                )
            ),
            PartItem(
                text = trimmedCustomPrompt.ifEmpty {
                    "Hãy đọc nội dung trong ảnh và trả lời ngắn gọn."
                }
            )
        )

        val candidateChain = buildCandidateModelChain(modelName, availableModels)

        try {
            for (candidateModel in candidateChain) {
                when (
                    val outcome = callSingleModelWithThinkingCompatibility(
                        model = candidateModel,
                        apiKey = cleanKey,
                        userParts = userParts,
                        customSystemPrompt = trimmedCustomPrompt.takeIf { it.isNotEmpty() },
                        thinkingLevel = thinkingLevel
                    )
                ) {
                    is CallOutcome.Success -> return@withContext formatAiOutput(outcome.text)
                    is CallOutcome.HttpError -> {
                        // Nếu lỗi 403 (API key không hợp lệ) -> dừng ngay
                        if (outcome.code == 403) return@withContext "!"
                        // Nếu lỗi 429 (hết quota), 503 (quá tải), 404 (model không khả dụng) -> tiếp tục thử model mạnh tiếp theo từ trên xuống dưới
                        continue
                    }
                    CallOutcome.NetworkOrEmptyError -> continue
                }
            }
            return@withContext "!"
        } catch (e: IOException) {
            return@withContext "!"
        } catch (e: Exception) {
            return@withContext "!"
        }
    }

    /**
     * Thực thi lời gọi HTTP tới Gemini REST API trên đúng model chỉ định.
     */
    private suspend fun executeGenerateContentCall(
        model: String,
        apiKey: String,
        userParts: List<PartItem>,
        customSystemPrompt: String?,
        thinkingConfig: ThinkingConfig?
    ): CallOutcome {
        val request = GeminiRequest(
            systemInstruction = customSystemPrompt?.let {
                ContentInstruction(parts = listOf(PartItem(text = it)))
            },
            contents = listOf(
                ContentItem(
                    role = "user",
                    parts = userParts
                )
            ),
            generationConfig = GenerationConfig(
                temperature = 0f,
                maxOutputTokens = 1024,
                thinkingConfig = thinkingConfig
            )
        )

        return try {
            val response = apiService.generateContent(
                model = model,
                apiKey = apiKey,
                request = request
            )
            if (!response.isSuccessful) {
                return CallOutcome.HttpError(response.code(), "HTTP ${response.code()}")
            }

            val parts = response.body()?.candidates?.firstOrNull()?.content?.parts.orEmpty()
            val outputText = parts
                .filter { it.thought != true && !it.text.isNullOrBlank() }
                .joinToString(" ") { it.text.orEmpty() }
                .ifBlank {
                    parts.mapNotNull { it.text }.joinToString(" ")
                }
                .trim()

            if (outputText.isNotBlank()) {
                CallOutcome.Success(outputText)
            } else {
                CallOutcome.NetworkOrEmptyError
            }
        } catch (_: Exception) {
            CallOutcome.NetworkOrEmptyError
        }
    }

    /**
     * Ping trực tiếp tới model bằng GET v1beta/models/{model}.
     * Tiêu tốn 0 quota generateContent, giúp kiểm tra kết nối & API Key an toàn tuyệt đối!
     */
    suspend fun pingModel(
        apiKey: String,
        modelName: String
    ): Result<PingResult> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key trống"))
        }

        val exactModel = modelName.trim().removePrefix("models/").ifBlank { "gemini-2.5-flash" }
        val startTime = System.currentTimeMillis()

        try {
            val response = apiService.getModel(exactModel, cleanKey)
            val latency = System.currentTimeMillis() - startTime
            if (!response.isSuccessful) {
                val code = response.code()
                val msg = when (code) {
                    400, 403 -> "API Key không hợp lệ hoặc bị từ chối (HTTP $code)"
                    404 -> "Model $exactModel không tồn tại hoặc không khả dụng trên key này (HTTP 404)"
                    429 -> "Giới hạn tần suất ping (HTTP 429)"
                    else -> "Lỗi khi ping model $exactModel (HTTP $code)"
                }
                return@withContext Result.failure(RuntimeException(msg))
            }

            val body = response.body()
            val display = body?.displayName ?: exactModel
            val inLimit = body?.inputTokenLimit ?: 1048576
            val outLimit = body?.outputTokenLimit ?: 8192

            Result.success(
                PingResult(
                    model = exactModel,
                    displayName = display,
                    latencyMs = latency,
                    inputTokenLimit = inLimit,
                    outputTokenLimit = outLimit
                )
            )
        } catch (e: Exception) {
            Result.failure(RuntimeException("Lỗi kết nối khi ping: ${e.message}"))
        }
    }

    /**
     * Kiểm tra kết nối trực tiếp với ĐÚNG modelName mà người dùng đang chọn trong Spinner.
     */
    suspend fun testApiKey(
        apiKey: String,
        modelName: String,
        thinkingLevel: String,
        customPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key trống"))
        }

        val exactModel = modelName.trim().removePrefix("models/").ifBlank { "gemini-2.5-flash" }
        val trimmedPrompt = customPrompt.trim()
        val testParts = listOf(
            PartItem(
                text = if (trimmedPrompt.isNotEmpty()) {
                    "$trimmedPrompt\n\nCâu hỏi thử: 1 + 1 = ? A. 1  B. 2  C. 3  D. 4"
                } else {
                    "Câu hỏi thử: 1 + 1 = ? A. 1  B. 2  C. 3  D. 4"
                }
            )
        )

        val thinkingConfig = buildCompatibleThinkingConfig(exactModel, thinkingLevel)

        if (thinkingConfig != null) {
            when (
                val firstTry = executeGenerateContentCall(
                    model = exactModel,
                    apiKey = cleanKey,
                    userParts = testParts,
                    customSystemPrompt = trimmedPrompt.takeIf { it.isNotEmpty() },
                    thinkingConfig = thinkingConfig
                )
            ) {
                is CallOutcome.Success -> {
                    return@withContext Result.success("${formatAiOutput(firstTry.text)} (model: $exactModel)")
                }
                is CallOutcome.HttpError -> {
                    if (firstTry.code == 429) {
                        return@withContext Result.failure(
                            RuntimeException("Model $exactModel đã hết hạn mức miễn phí (HTTP 429). Hãy chọn model khác trong danh sách.")
                        )
                    }
                    if (firstTry.code == 404) {
                        return@withContext Result.failure(
                            RuntimeException("Model $exactModel không khả dụng trên API Key này (HTTP 404).")
                        )
                    }
                }
                CallOutcome.NetworkOrEmptyError -> {}
            }
        }

        when (
            val secondTry = executeGenerateContentCall(
                model = exactModel,
                apiKey = cleanKey,
                userParts = testParts,
                customSystemPrompt = trimmedPrompt.takeIf { it.isNotEmpty() },
                thinkingConfig = null
            )
        ) {
            is CallOutcome.Success -> {
                return@withContext Result.success("${formatAiOutput(secondTry.text)} (model: $exactModel)")
            }
            is CallOutcome.HttpError -> {
                if (secondTry.code == 429) {
                    return@withContext Result.failure(
                        RuntimeException("Model $exactModel đã hết hạn mức miễn phí (HTTP 429). Hãy chọn model khác.")
                    )
                }
                return@withContext Result.failure(
                    RuntimeException("Lỗi từ model $exactModel (HTTP ${secondTry.code}).")
                )
            }
            CallOutcome.NetworkOrEmptyError -> {
                return@withContext Result.failure(
                    RuntimeException("Không nhận được phản hồi từ $exactModel. Kiểm tra lại kết nối mạng.")
                )
            }
        }
    }

    /**
     * Dữ liệu 1 mục gửi trong chế độ hàng loạt (Batch):
     * - Nếu sendRawImage = false (văn bản thông thường đủ dài & không chứa code): chỉ gửi extractedText để tiết kiệm ~90% token.
     * - Nếu sendRawImage = true (ảnh quá ít chữ như đồ thị/bảng hoặc chứa các dòng code): gửi nguyên ảnh JPEG Base64 để đảm bảo chính xác.
     */
    data class BatchItemInput(
        val index: Int,
        val fingerprint: String,
        val extractedText: String,
        val base64Jpeg: String,
        val sendRawImage: Boolean
    )

    /**
     * Kết quả xử lý hàng loạt kèm thông tin model thực tế đã trả lời (hỗ trợ tự động chuyển model khi hết hạn mức).
     */
    data class BatchAnalysisResult(
        val answers: Map<Int, String>,
        val modelUsed: String,
        val autoSwitchedFrom: String? = null
    )

    /**
     * Gửi HÀNG LOẠT câu hỏi/ảnh trong 1 lượt gọi Gemini API duy nhất để giảm tối đa tiêu hao Quota.
     * Khi model đang chọn bị hết hạn mức (HTTP 429 / RESOURCE_EXHAUSTED), tự động chuyển xuống model mạnh nhất
     * khả dụng tiếp theo từ trên xuống dưới để trả lời liền mạch không gián đoạn.
     */
    suspend fun analyzeBatchPayloadsWithFallback(
        items: List<BatchItemInput>,
        apiKey: String,
        modelName: String,
        thinkingLevel: String,
        customPrompt: String,
        availableModels: List<String> = emptyList()
    ): BatchAnalysisResult = withContext(Dispatchers.IO) {
        val exactModel = modelName.trim().removePrefix("models/").ifBlank { "gemini-2.5-flash" }
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank() || items.isEmpty()) {
            return@withContext BatchAnalysisResult(emptyMap(), exactModel, null)
        }

        val trimmedCustomPrompt = customPrompt.trim()

        val userParts = mutableListOf<PartItem>()
        val instructionHeader = buildString {
            append("Bạn nhận danh sách gồm ${items.size} mục câu hỏi được đánh số thứ tự. ")
            if (trimmedCustomPrompt.isNotEmpty()) {
                append("Yêu cầu trả lời cho từng mục: $trimmedCustomPrompt. ")
            } else {
                append("Hãy đọc kỹ nội dung (văn bản liền mạch hoặc hình ảnh đồ thị/bảng/code) và trả lời ngắn gọn, chính xác cho từng mục. ")
            }
            append("BẮT BUỘC định dạng kết quả đầu ra trên từng dòng theo mẫu: [#Số_thứ_tự]: <Đáp án> (Ví dụ: [#1]: A). Đảm bảo tính liền mạch và đầy đủ cho tất cả ${items.size} mục.")
        }
        userParts.add(PartItem(text = instructionHeader))

        for (item in items) {
            if (item.sendRawImage) {
                userParts.add(
                    PartItem(
                        text = "\n--- MỤC [#${item.index}] (Hình ảnh gốc: đồ thị / bảng biểu / code - hãy quan sát trực tiếp ảnh dưới đây) ---"
                    )
                )
                userParts.add(
                    PartItem(
                        inlineData = InlineData(
                            mimeType = "image/jpeg",
                            data = item.base64Jpeg
                        )
                    )
                )
                if (item.extractedText.isNotBlank()) {
                    userParts.add(
                        PartItem(text = "Văn bản phụ trợ nhận diện được cho [#${item.index}]:\n${item.extractedText}")
                    )
                }
            } else {
                userParts.add(
                    PartItem(
                        text = "\n--- MỤC [#${item.index}] (Văn bản trích xuất liền mạch từ ảnh để tối ưu token) ---\n${item.extractedText}"
                    )
                )
            }
        }

        val candidateChain = buildCandidateModelChain(exactModel, availableModels)

        try {
            for (candidateModel in candidateChain) {
                when (
                    val outcome = callSingleModelWithThinkingCompatibility(
                        model = candidateModel,
                        apiKey = cleanKey,
                        userParts = userParts,
                        customSystemPrompt = trimmedCustomPrompt.takeIf { it.isNotEmpty() },
                        thinkingLevel = thinkingLevel
                    )
                ) {
                    is CallOutcome.Success -> {
                        val parsed = parseBatchResponseText(outcome.text, items.map { it.index })
                        if (parsed.isNotEmpty()) {
                            return@withContext BatchAnalysisResult(
                                answers = parsed,
                                modelUsed = candidateModel,
                                autoSwitchedFrom = if (candidateModel != exactModel) exactModel else null
                            )
                        }
                    }
                    is CallOutcome.HttpError -> {
                        // Lỗi 403 (sai API key) -> dừng ngay
                        if (outcome.code == 403) {
                            return@withContext BatchAnalysisResult(emptyMap(), candidateModel, null)
                        }
                        // Lỗi 429 (hết hạn mức), 503 (quá tải), 404 (model không tồn tại) -> tự động chuyển sang model mạnh tiếp theo từ trên xuống dưới
                        continue
                    }
                    CallOutcome.NetworkOrEmptyError -> continue
                }
            }

            return@withContext BatchAnalysisResult(emptyMap(), exactModel, null)
        } catch (_: Exception) {
            return@withContext BatchAnalysisResult(emptyMap(), exactModel, null)
        }
    }

    suspend fun analyzeBatchPayloads(
        items: List<BatchItemInput>,
        apiKey: String,
        modelName: String,
        thinkingLevel: String,
        customPrompt: String,
        availableModels: List<String> = emptyList()
    ): Map<Int, String> = analyzeBatchPayloadsWithFallback(
        items = items,
        apiKey = apiKey,
        modelName = modelName,
        thinkingLevel = thinkingLevel,
        customPrompt = customPrompt,
        availableModels = availableModels
    ).answers

    /**
     * Tách kết quả trả về dạng [#1]: ... [#2]: ... thành Map theo đúng thứ tự từng ảnh đã chụp.
     */
    private fun parseBatchResponseText(rawText: String, expectedIndices: List<Int>): Map<Int, String> {
        val result = mutableMapOf<Int, String>()
        val regex = Regex("""\[#(\d+)\]\s*:\s*([^\n\r]+)""")
        for (match in regex.findAll(rawText)) {
            val idx = match.groupValues[1].toIntOrNull() ?: continue
            val ans = formatAiOutput(match.groupValues[2])
            if (ans.isNotBlank()) {
                result[idx] = ans
            }
        }

        if (result.isEmpty() && expectedIndices.size == 1) {
            result[expectedIndices.first()] = formatAiOutput(rawText)
        }
        return result
    }

    /**
     * Làm sạch kết quả trả về từ AI, tôn trọng hoàn toàn nội dung theo prompt tùy chỉnh của người dùng.
     */
    fun formatAiOutput(raw: String): String {
        val text = raw
            .replace(Regex("[*`#]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        return text.ifEmpty { "!" }
    }
}
