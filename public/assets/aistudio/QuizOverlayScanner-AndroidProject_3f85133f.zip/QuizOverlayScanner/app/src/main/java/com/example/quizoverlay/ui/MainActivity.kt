package com.example.quizoverlay.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.quizoverlay.R
import com.example.quizoverlay.data.SettingsRepository
import com.example.quizoverlay.databinding.ActivityMainBinding
import com.example.quizoverlay.network.GeminiClient
import com.example.quizoverlay.service.FloatingService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepository: SettingsRepository
    private val geminiClient = GeminiClient()
    private var isApiKeyVisible = false
    private var fetchModelsJob: Job? = null

    // Biến cờ chặn Spinner tự động ghi đè về vị trí 0 khi đang nạp danh sách model bằng code
    private var isUpdatingSpinnerProgrammatically = false
    private var currentSelectedModel: String = SettingsRepository.DEFAULT_MODEL

    // Danh sách model được cập nhật động từ Gemini API (sắp xếp từ mạnh nhất xuống nhẹ nhất từ trên xuống dưới)
    private val availableModels = SettingsRepository.DEFAULT_AVAILABLE_MODELS.toMutableList()
    private lateinit var modelAdapter: ArrayAdapter<String>

    private val thinkingLevels = listOf("low", "medium", "high")

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        updatePermissionStatusUi()
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        updatePermissionStatusUi()
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startFloatingOverlayService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(
                this,
                "Bạn cần cấp quyền chụp màn hình để biểu tượng có thể quét câu hỏi.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingsRepository = SettingsRepository.getInstance(this)

        setupDropdowns()
        setupSlidersRealtime()
        setupButtons()
        initializeSettingsAndListeners()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatusUi()
    }

    private fun setupDropdowns() {
        modelAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            availableModels
        )
        binding.spinnerModel.adapter = modelAdapter

        val thinkingAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("Low (Phản hồi nhanh nhất)", "Medium (Cân bằng)", "High (Suy luận sâu)")
        )
        binding.spinnerThinking.adapter = thinkingAdapter
    }

    /**
     * Đồng bộ danh sách Spinner và giữ nguyên chính xác model mà người dùng đã chọn.
     */
    private fun updateSpinnerModelsPreservingSelection(
        newModels: List<String>,
        preferredModel: String
    ): String {
        isUpdatingSpinnerProgrammatically = true
        try {
            availableModels.clear()
            availableModels.addAll(newModels)

            val cleanPreferred = preferredModel.trim().removePrefix("models/")
            if (cleanPreferred.isNotBlank() && !availableModels.contains(cleanPreferred)) {
                availableModels.add(0, cleanPreferred)
            }

            modelAdapter.notifyDataSetChanged()

            val targetIndex = availableModels.indexOf(cleanPreferred).takeIf { it >= 0 } ?: 0
            val finalChosenModel = availableModels.getOrElse(targetIndex) { SettingsRepository.DEFAULT_MODEL }
            currentSelectedModel = finalChosenModel
            binding.spinnerModel.setSelection(targetIndex, false)
            return finalChosenModel
        } finally {
            binding.spinnerModel.post {
                isUpdatingSpinnerProgrammatically = false
            }
        }
    }

    /**
     * Tự động gọi Gemini API (GET v1beta/models) để lấy danh sách các model khả dụng
     * tương ứng với API Key của người dùng nhưng VẪN GIỮ NGUYÊN model người dùng đã chọn trước đó.
     */
    private fun loadAvailableModelsForApiKey(apiKey: String) {
        val cleanKey = apiKey.trim()
        if (cleanKey.length < 15) return

        fetchModelsJob?.cancel()
        fetchModelsJob = lifecycleScope.launch {
            binding.tvApiStatus.text = "Trạng thái: Đang tự động dò danh sách Model AI khả dụng..."
            val savedModelInStore = settingsRepository.settingsFlow.first().modelName
            val preferred = currentSelectedModel.ifBlank { savedModelInStore }

            val result = geminiClient.fetchAvailableModels(cleanKey)
            result.onSuccess { models ->
                // Lưu danh sách model đã sắp xếp từ mạnh nhất xuống nhẹ nhất để FloatingService tự động fallback khi hết hạn mức
                settingsRepository.saveAvailableModels(models)
                val activeModel = updateSpinnerModelsPreservingSelection(
                    newModels = models,
                    preferredModel = preferred
                )
                settingsRepository.updateModelName(activeModel)

                binding.tvApiStatus.text =
                    "Trạng thái: Đã tải ${models.size} model (Xếp từ mạnh → nhẹ) · Đang dùng: $activeModel"
            }.onFailure { err ->
                binding.tvApiStatus.text =
                    "Trạng thái: Không tải được danh sách model (${err.message})"
            }
        }
    }

    private fun initializeSettingsAndListeners() {
        val savedKey = settingsRepository.getApiKey()
        binding.editApiKey.setText(savedKey)

        lifecycleScope.launch {
            // 1. Đọc toàn bộ cài đặt đã lưu trong DataStore trước tiên
            val initial = settingsRepository.settingsFlow.first()
            currentSelectedModel = initial.modelName.ifBlank { SettingsRepository.DEFAULT_MODEL }

            val sizeProgress = ((initial.iconSizeMm - 2.0f) * 10f).roundToInt().coerceIn(0, 130)
            binding.seekIconSize.progress = sizeProgress
            binding.tvIconSizeValue.text = String.format(
                Locale.US,
                "%.1f mm (~%d dp)",
                initial.iconSizeMm,
                (initial.iconSizeMm * 6.3f).roundToInt()
            )

            binding.seekIconAlpha.progress = initial.iconAlphaPercent
            binding.tvIconAlphaValue.text =
                if (initial.iconAlphaPercent == 0) "0% (Vô hình - vẫn chạm được)" else "${initial.iconAlphaPercent}%"

            binding.seekAnswerFont.progress = (initial.answerFontSizeSp - 10f).roundToInt().coerceIn(0, 18)
            binding.tvAnswerFontValue.text = "${initial.answerFontSizeSp.toInt()} sp"

            binding.seekAutoHide.progress = initial.autoHideSeconds.coerceIn(0, 30)
            binding.tvAutoHideValue.text =
                if (initial.autoHideSeconds == 0) "0 giây (Không tự ẩn)" else "${initial.autoHideSeconds} giây"

            binding.switchHideBorder.isChecked = initial.hideAnswerBorder
            binding.switchHideBorder.setOnCheckedChangeListener { _, isChecked ->
                lifecycleScope.launch {
                    settingsRepository.updateHideAnswerBorder(isChecked)
                }
            }

            binding.switchBatchMode.isChecked = initial.batchModeEnabled
            binding.switchBatchMode.setOnCheckedChangeListener { _, isChecked ->
                lifecycleScope.launch {
                    settingsRepository.updateBatchModeEnabled(isChecked)
                }
            }

            binding.btnClearCacheLog.text =
                "Xóa Log câu hỏi đã lưu (${settingsRepository.getCachedAnswerCount()} câu)"

            binding.editAnswerTextColor.setText(initial.answerTextColorHex)

            binding.editCustomPrompt.setText(initial.customPrompt)

            // Hiển thị đúng model đã lưu lên Spinner trước khi gắn listener
            updateSpinnerModelsPreservingSelection(
                newModels = availableModels.toList(),
                preferredModel = currentSelectedModel
            )

            val thinkingIdx = thinkingLevels.indexOf(initial.thinkingLevel).takeIf { it >= 0 } ?: 0
            binding.spinnerThinking.setSelection(thinkingIdx, false)

            // 2. Gắn listener chọn Model: chỉ cập nhật khi người dùng thực sự chọn trên Spinner
            binding.spinnerModel.onItemSelectedListener = SimpleItemSelectedListener { pos ->
                if (isUpdatingSpinnerProgrammatically) return@SimpleItemSelectedListener
                availableModels.getOrNull(pos)?.let { selected ->
                    currentSelectedModel = selected
                    lifecycleScope.launch {
                        settingsRepository.updateModelName(selected)
                        binding.tvApiStatus.text = "Trạng thái: Đã chọn model $selected"
                    }
                }
            }

            binding.spinnerThinking.onItemSelectedListener = SimpleItemSelectedListener { pos ->
                lifecycleScope.launch {
                    settingsRepository.updateThinkingLevel(thinkingLevels[pos])
                }
            }

            // 3. Nếu đã có API Key thì tải danh sách model khả dụng từ Google (vẫn giữ nguyên currentSelectedModel)
            if (savedKey.isNotBlank()) {
                loadAvailableModelsForApiKey(savedKey)
            }
        }

        // Lưu tự động API Key và tự động tải danh sách model khả dụng sau khi ngừng gõ 450ms
        binding.editApiKey.doAfterTextChanged { editable ->
            val key = editable?.toString()?.trim().orEmpty()
            settingsRepository.saveApiKey(key)
            if (key.length >= 20) {
                fetchModelsJob?.cancel()
                fetchModelsJob = lifecycleScope.launch {
                    delay(450L)
                    loadAvailableModelsForApiKey(key)
                }
            }
        }

        // Ô tự thêm Prompt cho phần trả lời (lưu realtime vào DataStore)
        binding.editCustomPrompt.doAfterTextChanged { editable ->
            val customPrompt = editable?.toString().orEmpty()
            lifecycleScope.launch {
                settingsRepository.updateCustomPrompt(customPrompt)
            }
        }

        // Đổi màu chữ đáp án bằng mã HEX hoặc các nút màu nhanh (lưu realtime vào DataStore)
        binding.editAnswerTextColor.doAfterTextChanged { editable ->
            val hex = editable?.toString()?.trim().orEmpty()
            if (hex.matches(Regex("^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$"))) {
                lifecycleScope.launch {
                    settingsRepository.updateAnswerTextColor(hex)
                }
            }
        }

        val applyQuickAnswerColor: (String) -> Unit = { hex ->
            binding.editAnswerTextColor.setText(hex)
            lifecycleScope.launch {
                settingsRepository.updateAnswerTextColor(hex)
            }
        }
        binding.btnColorWhite.setOnClickListener { applyQuickAnswerColor("#FFFFFF") }
        binding.btnColorGreen.setOnClickListener { applyQuickAnswerColor("#34D399") }
        binding.btnColorYellow.setOnClickListener { applyQuickAnswerColor("#FACC15") }
        binding.btnColorCyan.setOnClickListener { applyQuickAnswerColor("#38BDF8") }
        binding.btnColorRed.setOnClickListener { applyQuickAnswerColor("#FB7185") }
        binding.btnColorGray.setOnClickListener { applyQuickAnswerColor("#94A3B8") }

        binding.btnSaveApiKey.setOnClickListener {
            val apiKey = binding.editApiKey.text?.toString()?.trim().orEmpty()
            settingsRepository.saveApiKey(apiKey)
            if (apiKey.isEmpty()) {
                binding.tvApiStatus.text = "Trạng thái: Đã xóa API Key. Vui lòng nhập API Key mới."
            } else {
                loadAvailableModelsForApiKey(apiKey)
                Toast.makeText(this, "Đã lưu API Key & cập nhật danh sách Model!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnRefreshModels.setOnClickListener {
            val apiKey = binding.editApiKey.text?.toString()?.trim().orEmpty()
            if (apiKey.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập API Key trước.", Toast.LENGTH_SHORT).show()
            } else {
                loadAvailableModelsForApiKey(apiKey)
            }
        }

        binding.btnToggleShowKey.setOnClickListener {
            isApiKeyVisible = !isApiKeyVisible
            if (isApiKeyVisible) {
                binding.editApiKey.transformationMethod = HideReturnsTransformationMethod.getInstance()
                binding.btnToggleShowKey.text = "Ẩn Key"
            } else {
                binding.editApiKey.transformationMethod = PasswordTransformationMethod.getInstance()
                binding.btnToggleShowKey.text = "Hiện Key"
            }
            binding.editApiKey.setSelection(binding.editApiKey.text?.length ?: 0)
        }

        binding.btnTestApiKey.setOnClickListener {
            val apiKey = binding.editApiKey.text?.toString()?.trim().orEmpty()
            if (apiKey.isEmpty()) {
                binding.tvApiStatus.text = "Trạng thái: Vui lòng nhập Gemini API Key trước khi kiểm tra."
                return@setOnClickListener
            }

            settingsRepository.saveApiKey(apiKey)
            val selectedModel = availableModels.getOrElse(binding.spinnerModel.selectedItemPosition) {
                currentSelectedModel
            }
            currentSelectedModel = selectedModel

            binding.btnTestApiKey.isEnabled = false
            binding.tvApiStatus.text = "Trạng thái: Đang ping model $selectedModel (tiêu tốn 0 quota)..."

            lifecycleScope.launch {
                settingsRepository.updateModelName(selectedModel)
                val result = geminiClient.pingModel(apiKey, selectedModel)
                binding.btnTestApiKey.isEnabled = true
                result.onSuccess { ping ->
                    binding.tvApiStatus.text =
                        "Trạng thái: Ping thành công (${ping.latencyMs}ms)! Model ${ping.model} (${ping.displayName}) sẵn sàng · 0 Quota tiêu tốn"
                }.onFailure { err ->
                    binding.tvApiStatus.text =
                        "Trạng thái: Ping thất bại (${err.message})"
                }
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    FloatingService.isRunningFlow.collect { isRunning ->
                        binding.btnToggleService.text = if (isRunning) {
                            getString(R.string.btn_stop_floating)
                        } else {
                            getString(R.string.btn_start_floating)
                        }
                    }
                }
                // Tự động cập nhật Spinner khi FloatingService tự chuyển model xuống model khả dụng tiếp theo do hết hạn mức
                launch {
                    settingsRepository.settingsFlow.collect { settings ->
                        val latestModel = settings.modelName.trim().removePrefix("models/")
                        if (latestModel.isNotBlank() && latestModel != currentSelectedModel) {
                            val previous = currentSelectedModel
                            updateSpinnerModelsPreservingSelection(
                                newModels = availableModels.toList(),
                                preferredModel = latestModel
                            )
                            binding.tvApiStatus.text =
                                "Trạng thái: Model $previous hết hạn mức → Đã tự chuyển sang $latestModel"
                        }
                    }
                }
            }
        }
    }

    private fun setupSlidersRealtime() {
        binding.seekIconSize.max = 130
        binding.seekIconSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val sizeMm = 2.0f + (progress / 10f)
                val approxDp = (sizeMm * 6.3f).roundToInt()
                binding.tvIconSizeValue.text =
                    String.format(Locale.US, "%.1f mm (~%d dp)", sizeMm, approxDp)
                if (fromUser) {
                    lifecycleScope.launch {
                        settingsRepository.updateIconSizeMm(sizeMm)
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekIconAlpha.max = 100
        binding.seekIconAlpha.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvIconAlphaValue.text =
                    if (progress == 0) "0% (Vô hình - vẫn chạm được)" else "$progress%"
                if (fromUser) {
                    lifecycleScope.launch {
                        settingsRepository.updateIconAlphaPercent(progress)
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekAnswerFont.max = 18
        binding.seekAnswerFont.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val fontSp = (10 + progress).toFloat()
                binding.tvAnswerFontValue.text = "${fontSp.toInt()} sp"
                if (fromUser) {
                    lifecycleScope.launch {
                        settingsRepository.updateAnswerFontSizeSp(fontSp)
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekAutoHide.max = 30
        binding.seekAutoHide.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvAutoHideValue.text =
                    if (progress == 0) "0 giây (Không tự ẩn)" else "$progress giây"
                if (fromUser) {
                    lifecycleScope.launch {
                        settingsRepository.updateAutoHideSeconds(progress)
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupButtons() {
        binding.btnGrantOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            } else {
                Toast.makeText(this, "Đã cấp quyền hiển thị trên ứng dụng khác.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnRevealIconTemp.setOnClickListener {
            if (FloatingService.isRunningFlow.value) {
                val intent = Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_REVEAL_ICON
                }
                startService(intent)
                Toast.makeText(this, "Đang hiện rõ biểu tượng 100% trong 2 giây.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Hãy bật biểu tượng nổi trước.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnResetIconDefaults.setOnClickListener {
            lifecycleScope.launch {
                settingsRepository.resetIconDefaults()
                Toast.makeText(
                    this@MainActivity,
                    "Đã đặt lại kích thước 3.0mm (~19dp) và độ trong suốt 85%.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.btnClearCacheLog.setOnClickListener {
            settingsRepository.clearAnswerCacheLog()
            binding.btnClearCacheLog.text = "Xóa Log câu hỏi đã lưu (0 câu)"
            Toast.makeText(
                this,
                "Đã xóa bộ nhớ Log câu hỏi trùng lặp.",
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnToggleService.setOnClickListener {
            if (FloatingService.isRunningFlow.value) {
                val stopIntent = Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_STOP
                }
                startService(stopIntent)
            } else {
                checkPermissionsAndStartService()
            }
        }
    }

    private fun checkPermissionsAndStartService() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Vui lòng cấp quyền 'Hiển thị trên ứng dụng khác' trước.",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            return
        }

        val apiKey = binding.editApiKey.text?.toString()?.trim().orEmpty()
        if (apiKey.isEmpty()) {
            Toast.makeText(
                this,
                "Vui lòng nhập Gemini API Key ở mục số 2 trước khi bật biểu tượng nổi!",
                Toast.LENGTH_LONG
            ).show()
            binding.editApiKey.requestFocus()
            return
        }
        settingsRepository.saveApiKey(apiKey)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startFloatingOverlayService(resultCode: Int, resultData: Intent) {
        val serviceIntent = Intent(this, FloatingService::class.java).apply {
            action = FloatingService.ACTION_START
            putExtra(FloatingService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingService.EXTRA_RESULT_DATA, resultData)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun updatePermissionStatusUi() {
        val hasOverlay = Settings.canDrawOverlays(this)
        binding.tvOverlayStatus.text = if (hasOverlay) {
            "Quyền hiển thị trên ứng dụng khác (Overlay): ĐÃ CẤP"
        } else {
            "Quyền hiển thị trên ứng dụng khác (Overlay): CHƯA CẤP"
        }
        binding.btnGrantOverlay.isEnabled = !hasOverlay
    }
}

private class SimpleItemSelectedListener(
    private val onSelected: (position: Int) -> Unit
) : android.widget.AdapterView.OnItemSelectedListener {
    override fun onItemSelected(
        parent: android.widget.AdapterView<*>?,
        view: android.view.View?,
        position: Int,
        id: Long
    ) {
        onSelected(position)
    }

    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
}
