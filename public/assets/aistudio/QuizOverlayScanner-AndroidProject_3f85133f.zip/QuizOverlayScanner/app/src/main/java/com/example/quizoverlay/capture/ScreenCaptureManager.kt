package com.example.quizoverlay.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Kết quả chụp và tiền xử lý thông minh cho 1 lần bấm biểu tượng:
 * - base64Jpeg: Ảnh chụp màn hình đã nén JPEG (<=1280px).
 * - extractedText: Văn bản trích xuất từ ảnh với thứ tự dòng liền mạch.
 * - sendRawImage: True nếu ảnh có quá ít chữ (đồ thị, hình học, bảng biểu) HOẶC chứa các dòng code lập trình
 *   cần gửi nguyên ảnh gốc để đảm bảo độ chính xác tuyệt đối.
 * - reason: Lý do chọn chế độ gửi ("OCR_TEXT", "SPARSE_TEXT_OR_CHART", "CODE_DETECTED").
 * - fingerprint: Mã định danh chuẩn hóa của câu hỏi/ảnh dùng để tra cứu Log cũ (tránh tốn quota cho câu trùng lặp).
 */
data class CapturedScreenPayload(
    val base64Jpeg: String,
    val extractedText: String,
    val sendRawImage: Boolean,
    val reason: String,
    val fingerprint: String
)

class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth: Int = 1080
    private var screenHeight: Int = 1920
    private var screenDensityDpi: Int = DisplayMetrics.DENSITY_HIGH

    private val mainHandler = Handler(Looper.getMainLooper())
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private val frameLock = Any()
    private var lastCachedBitmap: Bitmap? = null

    // Bộ nhận diện văn bản trên thiết bị (Google ML Kit Text Recognition)
    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    companion object {
        private const val MAX_DIMENSION_PX = 1280 // Chiều dài tối đa ~1280px trước khi gửi
        private const val JPEG_QUALITY = 82       // Nén JPEG cân bằng độ nét chữ và dung lượng nhỏ
        private const val MIN_OCR_TEXT_CHARS = 45 // Dưới 45 ký tự thực -> coi là quá ít chữ (đồ thị/bảng/hình vẽ) -> gửi nguyên ảnh

        // Biểu thức chính quy phát hiện các dòng code lập trình (C/C++, Java, Kotlin, Python, JS, SQL, HTML...)
        private val CODE_SNIPPET_REGEX = Regex(
            pattern = """(\\bfun\\s+\\w+|\\bdef\\s+\\w+|\\bclass\\s+\\w+|\\bpublic\\s+static|\\bprivate\\s+|\\breturn\\b|#include\\s*<|System\\.out\\.|console\\.log|SELECT\\s+.+FROM|[{};]{2,}|=>|==|!=|<=|>=|\\bfor\\s*\\(|\\bwhile\\s*\\(|\\bif\\s*\\()""",
            option = RegexOption.IGNORE_CASE
        )
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            super.onStop()
            releaseVirtualDisplay()
        }
    }

    fun initializeProjection(resultCode: Int, resultData: Intent): Boolean {
        return try {
            release()
            updateScreenMetrics()

            val thread = HandlerThread("QuizScreenCaptureThread").apply { start() }
            captureThread = thread
            captureHandler = Handler(thread.looper)

            val projectionManager =
                context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = projectionManager.getMediaProjection(resultCode, resultData)
                ?: return false

            projection.registerCallback(projectionCallback, mainHandler)
            mediaProjection = projection

            setupVirtualDisplay()
            true
        } catch (e: Exception) {
            release()
            false
        }
    }

    fun isReady(): Boolean = mediaProjection != null && imageReader != null

    private fun updateScreenMetrics() {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            screenWidth = bounds.width().coerceAtLeast(1)
            screenHeight = bounds.height().coerceAtLeast(1)
            screenDensityDpi = context.resources.configuration.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels.coerceAtLeast(1)
            screenHeight = metrics.heightPixels.coerceAtLeast(1)
            screenDensityDpi = metrics.densityDpi
        }
    }

    private fun setupVirtualDisplay() {
        val reader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        )

        reader.setOnImageAvailableListener({ ir ->
            var img: Image? = null
            try {
                img = ir.acquireLatestImage()
                if (img != null) {
                    val bmp = extractCleanBitmapFromImage(img)
                    if (bmp != null) {
                        synchronized(frameLock) {
                            val old = lastCachedBitmap
                            lastCachedBitmap = bmp
                            if (old != null && old !== bmp && !old.isRecycled) {
                                old.recycle()
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    img?.close()
                } catch (_: Exception) {}
            }
        }, captureHandler ?: mainHandler)

        imageReader = reader

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "QuizOverlayScreenCapture",
            screenWidth,
            screenHeight,
            screenDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            captureHandler ?: mainHandler
        )
    }

    private fun extractCleanBitmapFromImage(capturedImage: Image): Bitmap? {
        var rawBitmap: Bitmap? = null
        return try {
            val width = capturedImage.width
            val height = capturedImage.height
            val plane = capturedImage.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width

            val bitmapWidth = width + rowPadding / pixelStride
            rawBitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            rawBitmap.copyPixelsFromBuffer(buffer)

            if (bitmapWidth != width) {
                val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, width, height)
                rawBitmap.recycle()
                cropped
            } else {
                rawBitmap
            }
        } catch (e: Exception) {
            rawBitmap?.recycle()
            null
        }
    }

    /**
     * Chụp màn hình và phân tích OCR trên thiết bị:
     * - Trích xuất văn bản liền mạch theo thứ tự từ trên xuống dưới để tối ưu token khi hỏi AI.
     * - Nếu văn bản quá ít (< 45 ký tự, ví dụ đồ thị, bảng biểu, hình học) HOẶC phát hiện các dòng code lập trình,
     *   đánh dấu sendRawImage = true để gửi nguyên ảnh gốc đảm bảo độ chính xác.
     * - Tạo fingerprint chuẩn hóa để kiểm tra câu hỏi trùng lặp trong Log cũ.
     */
    suspend fun captureScreenPayload(): CapturedScreenPayload? = withContext(Dispatchers.Default) {
        val reader = imageReader ?: return@withContext null

        delay(80)

        var workingBitmap: Bitmap? = null
        var scaledBitmap: Bitmap? = null

        try {
            var directImage: Image? = null
            try {
                directImage = reader.acquireLatestImage()
                if (directImage != null) {
                    workingBitmap = extractCleanBitmapFromImage(directImage)
                }
            } catch (_: Exception) {
            } finally {
                try {
                    directImage?.close()
                } catch (_: Exception) {}
            }

            if (workingBitmap == null) {
                synchronized(frameLock) {
                    val cached = lastCachedBitmap
                    if (cached != null && !cached.isRecycled) {
                        workingBitmap = cached.copy(Bitmap.Config.ARGB_8888, false)
                    }
                }
            }

            val sourceBitmap = workingBitmap ?: return@withContext null
            val width = sourceBitmap.width
            val height = sourceBitmap.height

            val maxSide = max(width, height)
            scaledBitmap = if (maxSide > MAX_DIMENSION_PX) {
                val scale = MAX_DIMENSION_PX.toFloat() / maxSide.toFloat()
                val targetW = (width * scale).roundToInt().coerceAtLeast(1)
                val targetH = (height * scale).roundToInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(sourceBitmap, targetW, targetH, true)
            } else {
                sourceBitmap
            }

            val base64Jpeg = ByteArrayOutputStream().use { outputStream ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, outputStream)
                val jpegBytes = outputStream.toByteArray()
                Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
            }

            // Nhận diện văn bản trên thiết bị bằng ML Kit, sắp xếp các khối theo trục Y -> X để giữ mạch nội dung liền lạc
            val extractedText = extractCoherentTextFromBitmap(scaledBitmap)
            val nonSpaceLength = extractedText.replace(Regex("\\s+"), "").length
            val hasCodeLines = containsProgrammingCode(extractedText)
            val isTooLittleText = nonSpaceLength < MIN_OCR_TEXT_CHARS

            val sendRawImage = isTooLittleText || hasCodeLines
            val reason = when {
                hasCodeLines -> "CODE_DETECTED"
                isTooLittleText -> "SPARSE_TEXT_OR_CHART"
                else -> "OCR_TEXT"
            }

            val fingerprint = buildQuestionFingerprint(
                extractedText = extractedText,
                base64Jpeg = base64Jpeg,
                useTextKey = !isTooLittleText
            )

            return@withContext CapturedScreenPayload(
                base64Jpeg = base64Jpeg,
                extractedText = extractedText,
                sendRawImage = sendRawImage,
                reason = reason,
                fingerprint = fingerprint
            )
        } catch (e: Exception) {
            return@withContext null
        } finally {
            if (scaledBitmap != null && scaledBitmap !== workingBitmap && !scaledBitmap.isRecycled) {
                scaledBitmap.recycle()
            }
            if (workingBitmap != null && !workingBitmap.isRecycled) {
                workingBitmap.recycle()
            }
        }
    }

    suspend fun captureScreenAsBase64Jpeg(): String? {
        return captureScreenPayload()?.base64Jpeg
    }

    /**
     * Trích xuất văn bản từ Bitmap và ghép nối liền mạch theo thứ tự từ trên xuống dưới.
     */
    private suspend fun extractCoherentTextFromBitmap(bitmap: Bitmap): String {
        return try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val visionText = textRecognizer.process(inputImage).await()
            val sortedBlocks = visionText.textBlocks.sortedWith(
                compareBy(
                    { it.boundingBox?.top ?: 0 },
                    { it.boundingBox?.left ?: 0 }
                )
            )
            sortedBlocks.joinToString("\n") { block ->
                block.lines.joinToString("\n") { line -> line.text.trim() }
            }.trim()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Phát hiện xem văn bản trong ảnh có chứa các dòng code lập trình hay không.
     */
    private fun containsProgrammingCode(text: String): Boolean {
        if (text.isBlank()) return false
        if (CODE_SNIPPET_REGEX.containsMatchIn(text)) return true
        val symbolCount = text.count { it in "{}();=[]<>" }
        return symbolCount >= 6
    }

    /**
     * Tạo mã băm SHA-256 chuẩn hóa cho câu hỏi để phát hiện câu hỏi trùng lặp trong Log cũ.
     */
    private fun buildQuestionFingerprint(
        extractedText: String,
        base64Jpeg: String,
        useTextKey: Boolean
    ): String {
        val normalizedSource = if (useTextKey && extractedText.isNotBlank()) {
            "TXT:" + extractedText
                .lowercase()
                .replace(Regex("\\s+"), " ")
                .trim()
        } else {
            "IMG:" + base64Jpeg.take(512) + ":" + base64Jpeg.takeLast(512) + ":" + base64Jpeg.length
        }

        val digest = MessageDigest.getInstance("SHA-256")
            .digest(normalizedSource.toByteArray(Charsets.UTF_8))
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }

    private fun releaseVirtualDisplay() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {}
        imageReader = null

        synchronized(frameLock) {
            lastCachedBitmap?.let {
                if (!it.isRecycled) it.recycle()
            }
            lastCachedBitmap = null
        }
    }

    fun release() {
        releaseVirtualDisplay()
        try {
            textRecognizer.close()
        } catch (_: Exception) {}
        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {}
        mediaProjection = null

        try {
            captureThread?.quitSafely()
        } catch (_: Exception) {}
        captureThread = null
        captureHandler = null
    }
}
