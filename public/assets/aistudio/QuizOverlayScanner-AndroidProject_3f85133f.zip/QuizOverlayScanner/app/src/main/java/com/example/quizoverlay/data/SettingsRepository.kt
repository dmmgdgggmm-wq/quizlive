package com.example.quizoverlay.data

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Khởi tạo singleton DataStore gắn với Application Context
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "quiz_overlay_settings")

/**
 * Data class đại diện cho toàn bộ trạng thái cài đặt giao diện & AI.
 * Được phát qua Flow để FloatingService cập nhật realtime ngay khi kéo thanh trượt hoặc sửa prompt.
 */
data class OverlaySettings(
    val iconSizeMm: Float = SettingsRepository.DEFAULT_ICON_SIZE_MM,         // Mặc định 3.0mm (~0.3cm, ~19dp)
    val iconAlphaPercent: Int = SettingsRepository.DEFAULT_ICON_ALPHA,       // Mặc định 85% (cho phép 0%..100%)
    val answerFontSizeSp: Float = SettingsRepository.DEFAULT_ANSWER_FONT_SP, // Mặc định 16sp
    val autoHideSeconds: Int = SettingsRepository.DEFAULT_AUTO_HIDE_SEC,     // Mặc định 5 giây (0 = không tự ẩn)
    val modelName: String = SettingsRepository.DEFAULT_MODEL,                // Mặc định "gemini-2.5-flash"
    val thinkingLevel: String = SettingsRepository.DEFAULT_THINKING_LEVEL,   // Mặc định "low" (low/medium/high)
    val customPrompt: String = "",                                           // Prompt do người dùng tự nhập (không ép prompt mặc định)
    val hideAnswerBorder: Boolean = false,                                   // Ẩn viền khung đáp án (chỉ hiện chữ trên nền trong suốt)
    val answerTextColorHex: String = SettingsRepository.DEFAULT_ANSWER_TEXT_COLOR, // Màu chữ hiển thị đáp án (HEX)
    val batchModeEnabled: Boolean = true,                                    // Chế độ gom hàng loạt: Chạm 1 lần = chụp +1, Ấn đè = gửi hàng loạt
    val iconX: Int = 0,
    val iconY: Int = 320,
    val answerX: Int = 120,
    val answerY: Int = 220,
    val answerWidthDp: Int = SettingsRepository.DEFAULT_ANSWER_WIDTH_DP,     // Mặc định 48dp
    val answerHeightDp: Int = SettingsRepository.DEFAULT_ANSWER_HEIGHT_DP    // Mặc định 32dp
)

class SettingsRepository(context: Context) {

    private val appContext = context.applicationContext

    companion object {
        // Giá trị mặc định theo đúng yêu cầu kỹ thuật
        const val DEFAULT_ICON_SIZE_MM = 3.0f       // ~0.3 cm (~19dp)
        const val MIN_ICON_SIZE_MM = 2.0f           // Tối thiểu 2mm
        const val MAX_ICON_SIZE_MM = 15.0f          // Tối đa 15mm

        const val DEFAULT_ICON_ALPHA = 85           // 0% -> 100%
        const val DEFAULT_ANSWER_FONT_SP = 16.0f    // Cỡ chữ khung trả lời
        const val DEFAULT_AUTO_HIDE_SEC = 5         // Tự ẩn sau X giây (0 = không tự ẩn)
        const val DEFAULT_ANSWER_TEXT_COLOR = "#FFFFFF" // Màu chữ đáp án mặc định (Trắng)

        const val DEFAULT_MODEL = "gemini-2.5-flash"
        const val FALLBACK_MODEL = "gemini-flash-latest"
        const val DEFAULT_THINKING_LEVEL = "low"    // low / medium / high

        // Danh sách model mặc định xếp từ MẠNH NHẤT (trên cùng) xuống NHẸ NHẤT / QUOTA CAO (dưới cùng)
        val DEFAULT_AVAILABLE_MODELS = listOf(
            "gemini-3.1-pro-preview",
            "gemini-3-flash-preview",
            "gemini-2.5-pro",
            "gemini-2.5-flash",
            "gemini-flash-latest",
            "gemini-2.5-flash-lite"
        )

        const val DEFAULT_ANSWER_WIDTH_DP = 48
        const val DEFAULT_ANSWER_HEIGHT_DP = 32
        const val MIN_ANSWER_SIZE_DP = 24           // Kích thước tối thiểu 24x24dp

        // Các khóa lưu trong Jetpack DataStore
        private val KEY_ICON_SIZE_MM = floatPreferencesKey("icon_size_mm")
        private val KEY_ICON_ALPHA = intPreferencesKey("icon_alpha_percent")
        private val KEY_ANSWER_FONT_SP = floatPreferencesKey("answer_font_sp")
        private val KEY_AUTO_HIDE_SEC = intPreferencesKey("auto_hide_seconds")
        private val KEY_MODEL_NAME = stringPreferencesKey("gemini_model_name")
        private val KEY_THINKING_LEVEL = stringPreferencesKey("gemini_thinking_level")
        private val KEY_CUSTOM_PROMPT = stringPreferencesKey("gemini_custom_prompt")
        private val KEY_HIDE_ANSWER_BORDER = booleanPreferencesKey("hide_answer_border")
        private val KEY_ANSWER_TEXT_COLOR = stringPreferencesKey("answer_text_color")
        private val KEY_BATCH_MODE_ENABLED = booleanPreferencesKey("batch_mode_enabled")

        private val KEY_ICON_X = intPreferencesKey("icon_x")
        private val KEY_ICON_Y = intPreferencesKey("icon_y")
        private val KEY_ANSWER_X = intPreferencesKey("answer_x")
        private val KEY_ANSWER_Y = intPreferencesKey("answer_y")
        private val KEY_ANSWER_W_DP = intPreferencesKey("answer_width_dp")
        private val KEY_ANSWER_H_DP = intPreferencesKey("answer_height_dp")

        private const val ENCRYPTED_PREFS_NAME = "secure_gemini_prefs"
        private const val ANSWER_CACHE_PREFS_NAME = "quiz_answer_cache_log"
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_AVAILABLE_MODELS_CSV = "gemini_available_models_csv"

        @Volatile
        private var INSTANCE: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsRepository(context).also { INSTANCE = it }
            }
        }
    }

    // Khởi tạo EncryptedSharedPreferences sử dụng khóa AES256_GCM trong Android Keystore
    private val securePrefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            appContext,
            ENCRYPTED_PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // Bộ nhớ Log cũ (Cache) để trả lời ngay khi phát hiện câu hỏi trùng lặp mà không tốn Quota
    private val answerCachePrefs: SharedPreferences by lazy {
        appContext.getSharedPreferences(ANSWER_CACHE_PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Luồng dữ liệu cấu hình phát realtime sang FloatingService và MainActivity.
     */
    val settingsFlow: Flow<OverlaySettings> = appContext.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            OverlaySettings(
                iconSizeMm = (prefs[KEY_ICON_SIZE_MM] ?: DEFAULT_ICON_SIZE_MM)
                    .coerceIn(MIN_ICON_SIZE_MM, MAX_ICON_SIZE_MM),
                iconAlphaPercent = (prefs[KEY_ICON_ALPHA] ?: DEFAULT_ICON_ALPHA)
                    .coerceIn(0, 100),
                answerFontSizeSp = (prefs[KEY_ANSWER_FONT_SP] ?: DEFAULT_ANSWER_FONT_SP)
                    .coerceIn(10f, 28f),
                autoHideSeconds = (prefs[KEY_AUTO_HIDE_SEC] ?: DEFAULT_AUTO_HIDE_SEC)
                    .coerceIn(0, 60),
                modelName = prefs[KEY_MODEL_NAME] ?: DEFAULT_MODEL,
                thinkingLevel = prefs[KEY_THINKING_LEVEL] ?: DEFAULT_THINKING_LEVEL,
                customPrompt = prefs[KEY_CUSTOM_PROMPT] ?: "",
                hideAnswerBorder = prefs[KEY_HIDE_ANSWER_BORDER] ?: false,
                answerTextColorHex = prefs[KEY_ANSWER_TEXT_COLOR] ?: DEFAULT_ANSWER_TEXT_COLOR,
                batchModeEnabled = prefs[KEY_BATCH_MODE_ENABLED] ?: true,
                iconX = prefs[KEY_ICON_X] ?: 0,
                iconY = prefs[KEY_ICON_Y] ?: 320,
                answerX = prefs[KEY_ANSWER_X] ?: 120,
                answerY = prefs[KEY_ANSWER_Y] ?: 220,
                answerWidthDp = (prefs[KEY_ANSWER_W_DP] ?: DEFAULT_ANSWER_WIDTH_DP)
                    .coerceAtLeast(MIN_ANSWER_SIZE_DP),
                answerHeightDp = (prefs[KEY_ANSWER_H_DP] ?: DEFAULT_ANSWER_HEIGHT_DP)
                    .coerceAtLeast(MIN_ANSWER_SIZE_DP)
            )
        }

    // Lưu và đọc API Key đã mã hóa
    fun saveApiKey(apiKey: String) {
        securePrefs.edit().putString(KEY_API_KEY, apiKey.trim()).apply()
    }

    fun getApiKey(): String {
        return securePrefs.getString(KEY_API_KEY, "")?.trim().orEmpty()
    }

    // Các hàm cập nhật realtime từng thuộc tính vào DataStore
    suspend fun updateIconSizeMm(sizeMm: Float) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ICON_SIZE_MM] = sizeMm.coerceIn(MIN_ICON_SIZE_MM, MAX_ICON_SIZE_MM)
        }
    }

    suspend fun updateIconAlphaPercent(alphaPercent: Int) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ICON_ALPHA] = alphaPercent.coerceIn(0, 100)
        }
    }

    suspend fun updateAnswerFontSizeSp(fontSp: Float) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ANSWER_FONT_SP] = fontSp.coerceIn(10f, 28f)
        }
    }

    suspend fun updateAutoHideSeconds(seconds: Int) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_AUTO_HIDE_SEC] = seconds.coerceIn(0, 60)
        }
    }

    suspend fun updateHideAnswerBorder(hide: Boolean) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_HIDE_ANSWER_BORDER] = hide
        }
    }

    suspend fun updateAnswerTextColor(colorHex: String) {
        val cleanHex = colorHex.trim().ifEmpty { DEFAULT_ANSWER_TEXT_COLOR }
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ANSWER_TEXT_COLOR] = cleanHex
        }
    }

    suspend fun updateBatchModeEnabled(enabled: Boolean) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_BATCH_MODE_ENABLED] = enabled
        }
    }

    // Tra cứu và lưu đáp án trong Log cũ để tránh tốn Quota khi gặp câu hỏi trùng lặp
    fun getCachedAnswer(fingerprint: String): String? {
        if (fingerprint.isBlank()) return null
        return answerCachePrefs.getString(fingerprint, null)?.takeIf { it.isNotBlank() && it != "!" }
    }

    fun saveCachedAnswer(fingerprint: String, answer: String) {
        val cleanAns = answer.trim()
        if (fingerprint.isNotBlank() && cleanAns.isNotBlank() && cleanAns != "!") {
            answerCachePrefs.edit().putString(fingerprint, cleanAns).apply()
        }
    }

    fun getCachedAnswerCount(): Int {
        return answerCachePrefs.all.size
    }

    fun clearAnswerCacheLog() {
        answerCachePrefs.edit().clear().apply()
    }

    // Lưu và đọc danh sách các model khả dụng đã xếp từ mạnh nhất xuống nhẹ nhất để tự động chuyển khi hết hạn mức
    fun saveAvailableModels(models: List<String>) {
        val cleaned = models.map { it.trim().removePrefix("models/") }.filter { it.isNotBlank() }.distinct()
        if (cleaned.isNotEmpty()) {
            securePrefs.edit().putString(KEY_AVAILABLE_MODELS_CSV, cleaned.joinToString(",")).apply()
        }
    }

    fun getAvailableModels(): List<String> {
        val raw = securePrefs.getString(KEY_AVAILABLE_MODELS_CSV, "")?.trim().orEmpty()
        if (raw.isBlank()) return DEFAULT_AVAILABLE_MODELS
        val list = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
        return if (list.isNotEmpty()) list else DEFAULT_AVAILABLE_MODELS
    }

    suspend fun updateModelName(model: String) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_MODEL_NAME] = model
        }
    }

    suspend fun updateThinkingLevel(level: String) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_THINKING_LEVEL] = level
        }
    }

    suspend fun updateCustomPrompt(prompt: String) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_CUSTOM_PROMPT] = prompt
        }
    }

    suspend fun saveIconPosition(x: Int, y: Int) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ICON_X] = x
            prefs[KEY_ICON_Y] = y
        }
    }

    suspend fun saveAnswerBounds(x: Int, y: Int, widthDp: Int, heightDp: Int) {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ANSWER_X] = x
            prefs[KEY_ANSWER_Y] = y
            prefs[KEY_ANSWER_W_DP] = widthDp.coerceAtLeast(MIN_ANSWER_SIZE_DP)
            prefs[KEY_ANSWER_H_DP] = heightDp.coerceAtLeast(MIN_ANSWER_SIZE_DP)
        }
    }

    /**
     * Đặt lại kích thước biểu tượng (3mm ~ 0.3cm) và độ trong suốt (85%) về mặc định.
     */
    suspend fun resetIconDefaults() {
        appContext.dataStore.edit { prefs ->
            prefs[KEY_ICON_SIZE_MM] = DEFAULT_ICON_SIZE_MM
            prefs[KEY_ICON_ALPHA] = DEFAULT_ICON_ALPHA
        }
    }
}
