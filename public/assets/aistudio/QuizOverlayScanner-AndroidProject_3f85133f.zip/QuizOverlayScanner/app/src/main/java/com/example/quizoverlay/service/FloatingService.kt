package com.example.quizoverlay.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.quizoverlay.R
import com.example.quizoverlay.capture.CapturedScreenPayload
import com.example.quizoverlay.capture.ScreenCaptureManager
import com.example.quizoverlay.data.OverlaySettings
import com.example.quizoverlay.data.SettingsRepository
import com.example.quizoverlay.network.GeminiClient
import com.example.quizoverlay.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

class FloatingService : Service() {

    companion object {
        const val ACTION_START = "com.example.quizoverlay.action.START"
        const val ACTION_STOP = "com.example.quizoverlay.action.STOP"
        const val ACTION_REVEAL_ICON = "com.example.quizoverlay.action.REVEAL_ICON"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val NOTIFICATION_CHANNEL_ID = "quiz_overlay_foreground_channel"
        private const val NOTIFICATION_ID = 1001

        private const val MIN_TOUCH_TARGET_DP = 40f     // Vùng chạm tối thiểu 40dp
        private const val REVEAL_DURATION_MS = 2000L    // Hiện rõ 100% trong 2 giây
        private const val LONG_PRESS_BATCH_MS = 500L    // Ấn đè >= 500ms để gửi hàng loạt các ảnh đã chụp

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var windowManager: WindowManager
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var screenCaptureManager: ScreenCaptureManager
    private val geminiClient = GeminiClient()

    private var floatingTouchContainer: FrameLayout? = null
    private var floatingVisualCircle: View? = null
    private var floatingCircleDrawable: GradientDrawable? = null
    private lateinit var floatingParams: WindowManager.LayoutParams

    private var answerContainer: FrameLayout? = null
    private var answerBoxDrawable: GradientDrawable? = null
    private var answerTextView: TextView? = null
    private var resizeHandleView: View? = null
    private lateinit var answerParams: WindowManager.LayoutParams

    private var currentSettings = OverlaySettings()
    private var isTemporarilyRevealed = false
    private var isScanningInProgress = false

    // Hàng đợi chứa các ảnh chụp màn hình để gửi hàng loạt khi người dùng ấn đè
    private val batchQueue = mutableListOf<CapturedScreenPayload>()
    private var longPressJob: Job? = null

    private var revealJob: Job? = null
    private var autoHideAnswerJob: Job? = null
    private var snapAnimator: ValueAnimator? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        settingsRepository = SettingsRepository.getInstance(this)
        screenCaptureManager = ScreenCaptureManager(this)

        createNotificationChannel()
        createFloatingIconOverlay()
        createAnswerOverlay()
        observeSettingsRealtime()

        _isRunningFlow.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForegroundServiceCleanly()
                return START_NOT_STICKY
            }

            ACTION_REVEAL_ICON -> {
                revealIconTemporarily(REVEAL_DURATION_MS)
                return START_STICKY
            }

            ACTION_START, null -> {
                startForegroundWithProjectionType()

                if (intent != null && intent.hasExtra(EXTRA_RESULT_CODE)) {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                    val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(EXTRA_RESULT_DATA)
                    }

                    if (resultCode != 0 && resultData != null) {
                        screenCaptureManager.initializeProjection(resultCode, resultData)
                    }
                }

                revealIconTemporarily(REVEAL_DURATION_MS)
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithProjectionType() {
        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observeSettingsRealtime() {
        serviceScope.launch {
            var isFirstLoad = true
            settingsRepository.settingsFlow.collectLatest { settings ->
                val previousSettings = currentSettings
                currentSettings = settings

                if (isFirstLoad) {
                    isFirstLoad = false
                    floatingParams.x = settings.iconX
                    floatingParams.y = settings.iconY
                    answerParams.x = settings.answerX
                    answerParams.y = settings.answerY
                }

                applyFloatingIconStyleRealtime()
                applyAnswerBoxStyleRealtime(
                    sizeChanged = previousSettings.answerWidthDp != settings.answerWidthDp ||
                        previousSettings.answerHeightDp != settings.answerHeightDp
                )
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingIconOverlay() {
        val minTouchPx = dpToPx(MIN_TOUCH_TARGET_DP)
        val visualPx = mmToPx(currentSettings.iconSizeMm)
        val containerSizePx = max(minTouchPx, visualPx)

        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            clipChildren = false
            clipToPadding = false
        }

        val circleDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#10B981"))
            setStroke(dpToPx(1.5f), Color.WHITE)
        }
        floatingCircleDrawable = circleDrawable

        val circleView = View(this).apply {
            background = circleDrawable
        }
        floatingVisualCircle = circleView

        val circleLayoutParams = FrameLayout.LayoutParams(
            visualPx,
            visualPx,
            Gravity.CENTER
        )
        container.addView(circleView, circleLayoutParams)

        floatingParams = WindowManager.LayoutParams(
            containerSizePx,
            containerSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = currentSettings.iconX
            y = currentSettings.iconY
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var longPressTriggered = false

        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    longPressJob?.cancel()
                    initialX = floatingParams.x
                    initialY = floatingParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    longPressTriggered = false

                    // Hẹn giờ ấn đè (500ms): khi người dùng giữ biểu tượng nổi sẽ gửi hàng loạt các ảnh đã chụp
                    longPressJob = serviceScope.launch {
                        delay(LONG_PRESS_BATCH_MS)
                        if (!isDragging) {
                            longPressTriggered = true
                            revealIconTemporarily(REVEAL_DURATION_MS)
                            flushBatchQueueAndAnswer()
                        }
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).roundToInt()
                    val dy = (event.rawY - initialTouchY).roundToInt()

                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        longPressJob?.cancel()
                        setVisualCircleAlpha(1.0f)
                    }

                    if (isDragging) {
                        val (screenW, screenH) = getScreenDimensions()
                        floatingParams.x = (initialX + dx).coerceIn(0, max(0, screenW - floatingParams.width))
                        floatingParams.y = (initialY + dy).coerceIn(0, max(0, screenH - floatingParams.height))
                        safeUpdateViewLayout(container, floatingParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressJob?.cancel()
                    if (isDragging) {
                        snapFloatingIconToNearestEdge()
                        revealIconTemporarily(REVEAL_DURATION_MS)
                    } else if (!longPressTriggered && event.actionMasked == MotionEvent.ACTION_UP) {
                        // Chạm 1 lần: Nếu bật chế độ hàng loạt -> chụp +1 ảnh vào hàng đợi; nếu tắt -> gửi ngay
                        if (currentSettings.batchModeEnabled) {
                            enqueueScreenCaptureToBatch()
                        } else {
                            triggerScreenScanAndAnswer()
                        }
                    }
                    true
                }

                else -> false
            }
        }

        floatingTouchContainer = container
        windowManager.addView(container, floatingParams)
    }

    private fun applyFloatingIconStyleRealtime() {
        val container = floatingTouchContainer ?: return
        val circleView = floatingVisualCircle ?: return

        val visualPx = mmToPx(currentSettings.iconSizeMm)
        val minTouchPx = dpToPx(MIN_TOUCH_TARGET_DP)
        val touchBoxPx = max(minTouchPx, visualPx)

        val circleLp = circleView.layoutParams as FrameLayout.LayoutParams
        if (circleLp.width != visualPx || circleLp.height != visualPx) {
            circleLp.width = visualPx
            circleLp.height = visualPx
            circleView.layoutParams = circleLp
        }

        if (floatingParams.width != touchBoxPx || floatingParams.height != touchBoxPx) {
            floatingParams.width = touchBoxPx
            floatingParams.height = touchBoxPx
            safeUpdateViewLayout(container, floatingParams)
        }

        val targetAlpha = if (isTemporarilyRevealed) {
            1.0f
        } else {
            (currentSettings.iconAlphaPercent.coerceIn(0, 100)) / 100f
        }
        setVisualCircleAlpha(targetAlpha)
    }

    private fun setVisualCircleAlpha(alpha: Float) {
        floatingVisualCircle?.alpha = alpha.coerceIn(0f, 1f)
    }

    private fun revealIconTemporarily(durationMs: Long) {
        revealJob?.cancel()
        isTemporarilyRevealed = true
        setVisualCircleAlpha(1.0f)

        revealJob = serviceScope.launch {
            delay(durationMs)
            isTemporarilyRevealed = false
            val configuredAlpha = (currentSettings.iconAlphaPercent.coerceIn(0, 100)) / 100f
            setVisualCircleAlpha(configuredAlpha)
        }
    }

    private fun snapFloatingIconToNearestEdge() {
        val container = floatingTouchContainer ?: return
        val (screenW, _) = getScreenDimensions()
        val startX = floatingParams.x
        val centerX = startX + floatingParams.width / 2
        val targetX = if (centerX < screenW / 2) 0 else max(0, screenW - floatingParams.width)

        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofInt(startX, targetX).apply {
            duration = 180L
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                floatingParams.x = animator.animatedValue as Int
                safeUpdateViewLayout(container, floatingParams)
            }
            start()
        }

        serviceScope.launch {
            settingsRepository.saveIconPosition(targetX, floatingParams.y)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createAnswerOverlay() {
        val widthPx = dpToPx(currentSettings.answerWidthDp.toFloat())
        val heightPx = dpToPx(currentSettings.answerHeightDp.toFloat())

        val boxDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(6f).toFloat()
            setColor(Color.TRANSPARENT) // Khung nền trong suốt 100%
            if (currentSettings.hideAnswerBorder) {
                setStroke(0, Color.TRANSPARENT)
            } else {
                setStroke(dpToPx(1f), Color.parseColor("#6694A3B8"))
            }
        }
        answerBoxDrawable = boxDrawable

        val container = FrameLayout(this).apply {
            background = boxDrawable
            visibility = View.GONE
        }

        val textView = TextView(this).apply {
            text = ""
            setTextColor(parseAnswerTextColor(currentSettings.answerTextColorHex))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, currentSettings.answerFontSizeSp)
            includeFontPadding = false
            // Đổ bóng chữ để đáp án luôn sắc nét và nổi bật trên nền trong suốt
            setShadowLayer(8f, 0f, 1.5f, Color.parseColor("#D9000000"))
        }
        answerTextView = textView

        container.addView(
            textView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        val handleSizePx = dpToPx(14f)
        // Không hiển thị dấu chấm màu xanh (dùng màu trong suốt, vẫn hỗ trợ chạm kéo thay đổi cỡ)
        val handleDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val handleView = View(this).apply {
            background = handleDrawable
        }
        resizeHandleView = handleView

        container.addView(
            handleView,
            FrameLayout.LayoutParams(
                handleSizePx,
                handleSizePx,
                Gravity.BOTTOM or Gravity.END
            ).apply {
                bottomMargin = dpToPx(2f)
                marginEnd = dpToPx(2f)
            }
        )

        answerParams = WindowManager.LayoutParams(
            widthPx,
            heightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = currentSettings.answerX
            y = currentSettings.answerY
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        var moveStartX = 0
        var moveStartY = 0
        var moveTouchX = 0f
        var moveTouchY = 0f
        var isMovingBox = false

        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    moveStartX = answerParams.x
                    moveStartY = answerParams.y
                    moveTouchX = event.rawX
                    moveTouchY = event.rawY
                    isMovingBox = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - moveTouchX).roundToInt()
                    val dy = (event.rawY - moveTouchY).roundToInt()
                    if (!isMovingBox && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isMovingBox = true
                    }
                    if (isMovingBox) {
                        val (screenW, screenH) = getScreenDimensions()
                        answerParams.x = (moveStartX + dx).coerceIn(0, max(0, screenW - answerParams.width))
                        answerParams.y = (moveStartY + dy).coerceIn(0, max(0, screenH - answerParams.height))
                        safeUpdateViewLayout(container, answerParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isMovingBox) {
                        persistAnswerBounds()
                    } else {
                        hideAnswerOverlayImmediately()
                    }
                    true
                }

                else -> false
            }
        }

        var initialW = 0
        var initialH = 0
        var resizeTouchX = 0f
        var resizeTouchY = 0f
        val minSizePx = dpToPx(SettingsRepository.MIN_ANSWER_SIZE_DP.toFloat())

        handleView.setOnTouchListener { v, event ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialW = answerParams.width
                    initialH = answerParams.height
                    resizeTouchX = event.rawX
                    resizeTouchY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dw = (event.rawX - resizeTouchX).roundToInt()
                    val dh = (event.rawY - resizeTouchY).roundToInt()
                    answerParams.width = max(minSizePx, initialW + dw)
                    answerParams.height = max(minSizePx, initialH + dh)
                    safeUpdateViewLayout(container, answerParams)
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    persistAnswerBounds()
                    true
                }

                else -> false
            }
        }

        answerContainer = container
        windowManager.addView(container, answerParams)
    }

    private fun parseAnswerTextColor(colorHex: String): Int {
        return try {
            Color.parseColor(colorHex.trim())
        } catch (_: Exception) {
            Color.WHITE
        }
    }

    private fun applyAnswerBoxStyleRealtime(sizeChanged: Boolean) {
        val container = answerContainer ?: return
        answerTextView?.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentSettings.answerFontSizeSp)
        answerTextView?.setTextColor(parseAnswerTextColor(currentSettings.answerTextColorHex))

        answerBoxDrawable?.let { drawable ->
            drawable.setColor(Color.TRANSPARENT)
            if (currentSettings.hideAnswerBorder) {
                drawable.setStroke(0, Color.TRANSPARENT)
            } else {
                drawable.setStroke(dpToPx(1f), Color.parseColor("#6694A3B8"))
            }
        }

        if (sizeChanged) {
            val minSizePx = dpToPx(SettingsRepository.MIN_ANSWER_SIZE_DP.toFloat())
            answerParams.width = max(minSizePx, dpToPx(currentSettings.answerWidthDp.toFloat()))
            answerParams.height = max(minSizePx, dpToPx(currentSettings.answerHeightDp.toFloat()))
            safeUpdateViewLayout(container, answerParams)
        }
    }

    private fun persistAnswerBounds() {
        val widthDp = pxToDp(answerParams.width)
        val heightDp = pxToDp(answerParams.height)
        serviceScope.launch {
            settingsRepository.saveAnswerBounds(
                x = answerParams.x,
                y = answerParams.y,
                widthDp = widthDp,
                heightDp = heightDp
            )
        }
    }

    private fun showAnswerText(resultText: String) {
        val container = answerContainer ?: return
        val textView = answerTextView ?: return

        autoHideAnswerJob?.cancel()
        textView.text = resultText
        container.visibility = View.VISIBLE

        val autoHideSec = currentSettings.autoHideSeconds
        if (autoHideSec > 0) {
            autoHideAnswerJob = serviceScope.launch {
                delay(autoHideSec * 1000L)
                container.visibility = View.GONE
            }
        }
    }

    private fun hideAnswerOverlayImmediately() {
        autoHideAnswerJob?.cancel()
        answerContainer?.visibility = View.GONE
    }

    /**
     * Bấm 1 lần (khi bật chế độ Gửi hàng loạt):
     * Chụp 1 ảnh màn hình, trích xuất OCR + phân loại (Text / Đồ thị / Code), cộng dồn vào hàng đợi (+1, +2, +3...).
     */
    private fun enqueueScreenCaptureToBatch() {
        if (isScanningInProgress) return
        if (!screenCaptureManager.isReady()) {
            showAnswerText("!")
            return
        }

        isScanningInProgress = true
        serviceScope.launch {
            try {
                autoHideAnswerJob?.cancel()
                floatingTouchContainer?.visibility = View.INVISIBLE
                answerContainer?.visibility = View.INVISIBLE

                delay(120L)

                val payload = screenCaptureManager.captureScreenPayload()
                floatingTouchContainer?.visibility = View.VISIBLE

                if (payload == null) {
                    showAnswerText("!")
                    return@launch
                }

                batchQueue.add(payload)
                showAnswerText("+${batchQueue.size}")
            } catch (_: Exception) {
                floatingTouchContainer?.visibility = View.VISIBLE
                showAnswerText("!")
            } finally {
                isScanningInProgress = false
            }
        }
    }

    /**
     * Ấn đè (Long Press >= 500ms):
     * - Nếu chưa có ảnh nào trong hàng đợi, tự động chụp màn hình hiện tại vào hàng đợi.
     * - Kiểm tra từng câu hỏi trong hàng đợi với Log cũ (Cache): nếu trùng lặp thì lấy ngay đáp án từ Log cũ (0 tốn Quota).
     * - Những câu chưa có trong Log cũ được gom lại gửi 1 lượt duy nhất lên Gemini (ưu tiên gửi OCR Text liền mạch,
     *   trừ trường hợp ảnh ít chữ như đồ thị/bảng hoặc chứa các dòng code thì gửi nguyên ảnh gốc).
     */
    private fun flushBatchQueueAndAnswer() {
        if (isScanningInProgress) return

        val apiKey = settingsRepository.getApiKey()
        if (!screenCaptureManager.isReady() || apiKey.isBlank()) {
            showAnswerText("!")
            return
        }

        isScanningInProgress = true
        serviceScope.launch {
            try {
                autoHideAnswerJob?.cancel()

                // Nếu người dùng ấn đè ngay khi hàng đợi đang trống -> chụp luôn màn hình hiện tại
                if (batchQueue.isEmpty()) {
                    floatingTouchContainer?.visibility = View.INVISIBLE
                    answerContainer?.visibility = View.INVISIBLE
                    delay(120L)
                    val singlePayload = screenCaptureManager.captureScreenPayload()
                    floatingTouchContainer?.visibility = View.VISIBLE
                    if (singlePayload != null) {
                        batchQueue.add(singlePayload)
                    }
                }

                if (batchQueue.isEmpty()) {
                    showAnswerText("!")
                    return@launch
                }

                val queuedItems = batchQueue.toList()
                batchQueue.clear()

                answerTextView?.text = "…(${queuedItems.size})"
                answerContainer?.visibility = View.VISIBLE

                val latestSettings = settingsRepository.settingsFlow.first()
                currentSettings = latestSettings

                val finalAnswersByIndex = mutableMapOf<Int, String>()
                val uncachedInputs = mutableListOf<GeminiClient.BatchItemInput>()
                val fingerprintByIndex = mutableMapOf<Int, String>()

                // 1. Kiểm tra câu hỏi trùng lặp trong Log cũ (Cache) để tiết kiệm Quota
                queuedItems.forEachIndexed { idx, item ->
                    val itemNumber = idx + 1
                    fingerprintByIndex[itemNumber] = item.fingerprint
                    val cachedAns = settingsRepository.getCachedAnswer(item.fingerprint)
                    if (cachedAns != null) {
                        finalAnswersByIndex[itemNumber] = cachedAns
                    } else {
                        // Chỉ thêm lần xuất hiện đầu tiên nếu trong cùng 1 batch có 2 ảnh giống hệt nhau
                        val alreadyQueuedSameFingerprint = uncachedInputs.any { it.fingerprint == item.fingerprint }
                        if (!alreadyQueuedSameFingerprint) {
                            uncachedInputs.add(
                                GeminiClient.BatchItemInput(
                                    index = itemNumber,
                                    fingerprint = item.fingerprint,
                                    extractedText = item.extractedText,
                                    base64Jpeg = item.base64Jpeg,
                                    sendRawImage = item.sendRawImage
                                )
                            )
                        }
                    }
                }

                // 2. Gửi 1 lượt duy nhất tất cả các câu chưa có trong Log cũ lên Gemini API
                //    Nếu model đang chọn hết hạn mức (HTTP 429), tự động chuyển xuống model mạnh nhất khả dụng tiếp theo từ trên xuống dưới
                if (uncachedInputs.isNotEmpty()) {
                    val batchResult = geminiClient.analyzeBatchPayloadsWithFallback(
                        items = uncachedInputs,
                        apiKey = apiKey,
                        modelName = latestSettings.modelName,
                        thinkingLevel = latestSettings.thinkingLevel,
                        customPrompt = latestSettings.customPrompt,
                        availableModels = settingsRepository.getAvailableModels()
                    )

                    // Nếu đã tự động chuyển sang model khả dụng tiếp theo do hết quota -> lưu model mới vào DataStore để các lần sau dùng luôn
                    if (batchResult.autoSwitchedFrom != null && batchResult.modelUsed.isNotBlank()) {
                        settingsRepository.updateModelName(batchResult.modelUsed)
                    }

                    // Lưu kết quả mới vào Log cũ và điền vào danh sách kết quả
                    for (input in uncachedInputs) {
                        val ans = batchResult.answers[input.index] ?: "!"
                        finalAnswersByIndex[input.index] = ans
                        if (ans != "!") {
                            settingsRepository.saveCachedAnswer(input.fingerprint, ans)
                        }
                    }
                }

                // 3. Điền nốt các câu trùng lặp ngay trong cùng 1 batch (nếu có) và ghép chuỗi hiển thị
                val formattedOutput = if (queuedItems.size == 1) {
                    val fp = fingerprintByIndex[1].orEmpty()
                    finalAnswersByIndex[1] ?: settingsRepository.getCachedAnswer(fp) ?: "!"
                } else {
                    (1..queuedItems.size).joinToString(" | ") { num ->
                        val fp = fingerprintByIndex[num].orEmpty()
                        val ans = finalAnswersByIndex[num] ?: settingsRepository.getCachedAnswer(fp) ?: "!"
                        "#$num: $ans"
                    }
                }

                showAnswerText(formattedOutput)
            } catch (_: Exception) {
                floatingTouchContainer?.visibility = View.VISIBLE
                showAnswerText("!")
            } finally {
                isScanningInProgress = false
            }
        }
    }

    private fun triggerScreenScanAndAnswer() {
        if (isScanningInProgress) return

        val apiKey = settingsRepository.getApiKey()
        if (!screenCaptureManager.isReady() || apiKey.isBlank()) {
            showAnswerText("!")
            return
        }

        isScanningInProgress = true
        serviceScope.launch {
            try {
                autoHideAnswerJob?.cancel()
                floatingTouchContainer?.visibility = View.INVISIBLE
                answerContainer?.visibility = View.INVISIBLE

                delay(120L)

                val payload = screenCaptureManager.captureScreenPayload()

                floatingTouchContainer?.visibility = View.VISIBLE

                if (payload == null) {
                    showAnswerText("!")
                    return@launch
                }

                // Kiểm tra Log cũ trước khi gọi API
                val cached = settingsRepository.getCachedAnswer(payload.fingerprint)
                if (cached != null) {
                    showAnswerText(cached)
                    return@launch
                }

                answerTextView?.text = "…"
                answerContainer?.visibility = View.VISIBLE

                val latestSettings = settingsRepository.settingsFlow.first()
                currentSettings = latestSettings

                val batchSingleResult = geminiClient.analyzeBatchPayloadsWithFallback(
                    items = listOf(
                        GeminiClient.BatchItemInput(
                            index = 1,
                            fingerprint = payload.fingerprint,
                            extractedText = payload.extractedText,
                            base64Jpeg = payload.base64Jpeg,
                            sendRawImage = payload.sendRawImage
                        )
                    ),
                    apiKey = apiKey,
                    modelName = latestSettings.modelName,
                    thinkingLevel = latestSettings.thinkingLevel,
                    customPrompt = latestSettings.customPrompt,
                    availableModels = settingsRepository.getAvailableModels()
                )

                // Tự động lưu model khả dụng mới nếu model cũ bị hết hạn mức (HTTP 429)
                if (batchSingleResult.autoSwitchedFrom != null && batchSingleResult.modelUsed.isNotBlank()) {
                    settingsRepository.updateModelName(batchSingleResult.modelUsed)
                }

                val answer = batchSingleResult.answers[1] ?: "!"
                if (answer != "!") {
                    settingsRepository.saveCachedAnswer(payload.fingerprint, answer)
                }

                showAnswerText(answer)
            } catch (e: Exception) {
                floatingTouchContainer?.visibility = View.VISIBLE
                showAnswerText("!")
            } finally {
                isScanningInProgress = false
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val revealIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_REVEAL_ICON
        }
        val revealPendingIntent = PendingIntent.getService(
            this,
            1,
            revealIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_content))
            .setContentIntent(contentPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_view,
                getString(R.string.action_reveal_icon),
                revealPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.action_stop_service),
                stopPendingIntent
            )
            .build()
    }

    private fun stopForegroundServiceCleanly() {
        _isRunningFlow.value = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        _isRunningFlow.value = false
        revealJob?.cancel()
        autoHideAnswerJob?.cancel()
        snapAnimator?.cancel()
        serviceScope.cancel()

        screenCaptureManager.release()

        floatingTouchContainer?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        floatingTouchContainer = null

        answerContainer?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        answerContainer = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun mmToPx(mm: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_MM,
            mm,
            resources.displayMetrics
        ).roundToInt().coerceAtLeast(4)
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        ).roundToInt().coerceAtLeast(1)
    }

    private fun pxToDp(px: Int): Int {
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        return (px / density).roundToInt().coerceAtLeast(SettingsRepository.MIN_ANSWER_SIZE_DP)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun safeUpdateViewLayout(view: View, params: WindowManager.LayoutParams) {
        if (view.isAttachedToWindow) {
            try {
                windowManager.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
    }
}
