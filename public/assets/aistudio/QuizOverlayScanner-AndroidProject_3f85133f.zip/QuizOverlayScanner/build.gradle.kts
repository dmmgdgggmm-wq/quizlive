// Top-level build file cấu hình plugin chung cho toàn bộ project
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
